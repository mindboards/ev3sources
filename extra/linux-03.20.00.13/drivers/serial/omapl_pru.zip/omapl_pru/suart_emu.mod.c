#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x708ffad, "module_layout" },
	{ 0xadf42bd5, "__request_region" },
	{ 0x4fa869bc, "kmalloc_caches" },
	{ 0x12da5bb2, "__kmalloc" },
	{ 0xc3df5502, "clk_enable" },
	{ 0x762b74dc, "uart_write_wakeup" },
	{ 0x6980fe91, "param_get_int" },
	{ 0xf9742cc1, "uart_add_one_port" },
	{ 0x788fe103, "iomem_resource" },
	{ 0x9c621eea, "dev_set_drvdata" },
	{ 0x586958de, "clk_disable" },
	{ 0x5641485b, "tty_termios_encode_baud_rate" },
	{ 0x2e1ca751, "clk_put" },
	{ 0xe0a982ab, "uart_unregister_driver" },
	{ 0xff964b25, "param_set_int" },
	{ 0xc3d93499, "uart_update_timeout" },
	{ 0x56921c52, "clk_get_rate" },
	{ 0x173b9ebb, "uart_remove_one_port" },
	{ 0xa24d2473, "davinci_iounmap" },
	{ 0xe707d823, "__aeabi_uidiv" },
	{ 0x5f754e5a, "memset" },
	{ 0x9ad0d04a, "davinci_ioremap" },
	{ 0xc8c5cdd2, "do_SAK" },
	{ 0x448212fa, "down_trylock" },
	{ 0xea147363, "printk" },
	{ 0xf6524ce2, "platform_get_resource" },
	{ 0xfda85a7d, "request_threaded_irq" },
	{ 0x2a3491c4, "platform_driver_register" },
	{ 0x43b0c9c3, "preempt_schedule" },
	{ 0x2196324, "__aeabi_idiv" },
	{ 0x1478ade5, "tty_insert_flip_string_flags" },
	{ 0x91c1b2a3, "kmem_cache_alloc" },
	{ 0xe9c2f672, "dev_driver_string" },
	{ 0x9bce482f, "__release_region" },
	{ 0x2315b128, "clk_get" },
	{ 0x409873e3, "tty_termios_baud_rate" },
	{ 0x37a0cba, "kfree" },
	{ 0x9d669763, "memcpy" },
	{ 0x8cf51d15, "up" },
	{ 0xe9925a50, "uart_register_driver" },
	{ 0x17c8ad8e, "request_firmware" },
	{ 0xf94ba8a0, "tty_flip_buffer_push" },
	{ 0xe2704751, "platform_get_irq" },
	{ 0x24555aa7, "platform_driver_unregister" },
	{ 0x9e4567ff, "uart_get_baud_rate" },
	{ 0x7e075a6f, "dev_get_drvdata" },
	{ 0xb703911e, "release_firmware" },
	{ 0xf20dabd8, "free_irq" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";

