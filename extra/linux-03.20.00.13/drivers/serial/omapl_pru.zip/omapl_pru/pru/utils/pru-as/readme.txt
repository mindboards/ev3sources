This directory contains binaries for running on a PC.

|--\bin
   |
   |--\linux          Contains PRU assembler for Linux system.
   |
   |--\windows        Contains PRU assembler for DOS/Windows system.

